Some modified functions from David Kahle and Hadley Wickham's `ggmap` package that allow you to include a customized key for the Google Maps API.
